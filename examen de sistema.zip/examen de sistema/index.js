document.addEventListener('DOMContentLoaded', () => {
    const cartIcon = document.querySelector('.icon-cart');
    const cartProductsContainer = document.querySelector('.container-cart-products');
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const productCount = document.getElementById('contador-productos');
    const totalPagar = document.querySelector('.total-pagar');
    let cart = [];

    cartIcon.addEventListener('click', () => {
        cartProductsContainer.classList.toggle('hidden-cart');
    });

    addToCartButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const item = e.target.closest('.item');
            const productName = item.querySelector('h2').textContent;
            const productPrice = parseFloat(item.querySelector('.price').textContent.replace('$', ''));

            const productInCart = cart.find(product => product.name === productName);

            if (productInCart) {
                productInCart.quantity += 1;
            } else {
                cart.push({
                    name: productName,
                    price: productPrice,
                    quantity: 1
                });
            }

            updateCart();
        });
    });

    function updateCart() {
        productCount.textContent = cart.reduce((acc, product) => acc + product.quantity, 0);
        totalPagar.textContent = `$${cart.reduce((acc, product) => acc + (product.price * product.quantity), 0).toFixed(2)}`;

        const cartHTML = cart.map(product => `
            <div class="cart-product">
                <div class="info-cart-product">
                    <span class="cantidad-producto-carrito">${product.quantity}</span>
                    <p class="titulo-producto-carrito">${product.name}</p>
                    <span class="precio-producto-carrito">$${(product.price * product.quantity).toFixed(2)}</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="icon-close" data-product="${product.name}">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </div>
        `).join('');

        cartProductsContainer.innerHTML = `
            ${cartHTML}
            <div class="cart-total">
                <h3>Total:</h3>
                <span class="total-pagar">${totalPagar.textContent}</span>
            </div>
        `;

        document.querySelectorAll('.icon-close').forEach(icon => {
            icon.addEventListener('click', (e) => {
                const productName = e.target.getAttribute('data-product');
                cart = cart.filter(product => product.name !== productName);
                updateCart();
            });
        });
    }
});

